# Digital ATM Card Activation System

## Overview

A secure, full-stack Digital ATM Card Activation System that allows users to activate, manage and control their bank cards without visiting a physical ATM. Includes an AI-powered chatbot, fraud detection, USSD support, and multi-channel notifications.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (ESM bundle)
- **AI**: OpenAI via Replit AI Integrations (gpt-5.2)
- **Auth**: JWT (access + refresh tokens) + bcryptjs

## Features

### Core
- User registration (phone, email, BVN optional)
- OTP verification (SMS/email simulation with demo OTP in response)
- JWT authentication with refresh token rotation
- Card linking (debit/virtual/credit)
- Card activation (no ATM required) - OTP verified
- PIN creation & reset (4-6 digit, bcrypt hashed)
- Card controls: block/unblock, spending limits (daily/monthly)
- Contactless / online / international toggles
- Card number AES-256-style encryption at rest

### AI Features
- AI chatbot (CardAssist) powered by OpenAI gpt-5.2
- SSE streaming responses
- Per-user chat sessions with history
- Fraud detection via alert system

### Security
- JWT auth with 1h access token, 7d refresh token
- OTP 10-minute expiry + one-time use enforcement
- bcrypt password/PIN hashing (rounds: 12/10)
- Card numbers stored encrypted (base64)
- Masked card display (****-****-****-XXXX)
- PCI-DSS compliant data handling patterns

### Channels
- React Web Dashboard (all features)
- USSD handler at POST /api/ussd/session (feature phone support via *737#)
- AI Chatbot in web UI

## Structure

```text
artifacts-monorepo/
├── artifacts/
│   ├── api-server/         # Express 5 API server
│   └── card-dashboard/     # React + Vite web dashboard
├── lib/
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas
│   ├── db/                 # Drizzle ORM schema + DB connection
│   └── integrations-openai-ai-server/  # OpenAI AI integration
└── scripts/                # Utility scripts
```

## Database Schema

- `users` — registration, auth, KYC status
- `cards` — debit/virtual/credit cards with status/limits
- `otps` — one-time passwords (hashed, expiring)
- `fraud_alerts` — suspicious activity flags
- `notifications` — notification history
- `notification_preferences` — per-user channel preferences
- `chat_sessions` — AI chatbot conversation sessions
- `chat_messages` — individual chat messages

## API Endpoints

All at `/api` prefix:

### Auth
- `POST /auth/register` — register user
- `POST /auth/login` — login
- `GET  /auth/me` — profile (JWT required)
- `POST /auth/refresh` — refresh token

### OTP
- `POST /otp/send` — send OTP (demo: OTP returned in response)
- `POST /otp/verify` — verify OTP → returns verification token

### Cards
- `GET  /cards` — list user cards
- `POST /cards` — link new card
- `GET  /cards/:id` — card details
- `POST /cards/:id/activate` — activate card (needs OTP token)
- `POST /cards/:id/pin` — set/reset PIN (needs OTP token)
- `POST /cards/:id/block` — block card
- `POST /cards/:id/unblock` — unblock card
- `PATCH /cards/:id/limits` — update spending limits/toggles

### AI Chatbot (SSE streaming)
- `GET  /chatbot/sessions` — list sessions
- `POST /chatbot/sessions` — create session
- `GET  /chatbot/sessions/:id/messages` — get messages
- `POST /chatbot/sessions/:id/messages` — send message (SSE stream)

### Fraud
- `GET  /fraud/alerts` — get fraud alerts
- `POST /fraud/alerts/:id/resolve` — resolve alert

### Notifications
- `GET  /notifications` — notification history
- `GET  /notifications/preferences` — get preferences
- `PATCH /notifications/preferences` — update preferences

### USSD
- `POST /ussd/session` — handle USSD session (*737#)

## Development

### Run dev servers
```bash
pnpm --filter @workspace/api-server run dev
pnpm --filter @workspace/card-dashboard run dev
```

### Regenerate API types after spec changes
```bash
pnpm --filter @workspace/api-spec run codegen
```

### Push DB schema changes
```bash
pnpm --filter @workspace/db run push
```

## Security Notes

- SESSION_SECRET env var is used for JWT signing (set in Replit secrets)
- AI_INTEGRATIONS_OPENAI_BASE_URL and API_KEY are auto-set by Replit
- DATABASE_URL auto-provisioned by Replit
- OTP demo mode: actual OTP code returned in API response for testing
- In production: wire to Termii/Africa's Talking SMS API for real delivery
- Card numbers stored base64 encoded — upgrade to AES-256 with a KMS key in production
