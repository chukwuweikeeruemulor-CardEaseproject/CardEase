import { Layout } from "@/components/layout";
import { useState } from "react";
import { useUssd } from "@/hooks/use-ussd";
import { Phone, CornerDownLeft, Loader2, SignalHigh, BatteryMedium, Wifi } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function UssdSimulator() {
  const [sessionId] = useState(`session-${Math.random().toString(36).substr(2, 9)}`);
  const [inputText, setInputText] = useState("");
  const [history, setHistory] = useState(""); // Accumulates *737#*1*2
  const [screenText, setScreenText] = useState("Dial *737# to start\nVaultX Offline Service");
  const [isSessionActive, setIsSessionActive] = useState(false);
  
  const ussdMutation = useUssd();

  const handleSend = async () => {
    if (!inputText && !isSessionActive) return;

    const code = isSessionActive ? "" : inputText; // initial service code
    const newHistory = isSessionActive ? `${history}*${inputText}` : inputText;
    
    setHistory(newHistory);
    
    try {
      const res = await ussdMutation.mutateAsync({
        data: {
          sessionId,
          serviceCode: code || "*737#",
          phoneNumber: "+2348000000000",
          text: newHistory
        }
      });

      setScreenText(res.message);
      setIsSessionActive(res.responseType === "CON");
      setInputText("");
      
      if (res.responseType === "END") {
        setHistory(""); // Reset for next session
      }
    } catch (e) {
      setScreenText("Network Error\nPlease try again later.");
      setIsSessionActive(false);
      setHistory("");
    }
  };

  return (
    <Layout>
      <div className="flex flex-col items-center justify-center min-h-[70vh]">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-2 flex justify-center items-center gap-3">
            <Phone className="w-8 h-8 text-primary" /> USSD Simulator
          </h1>
          <p className="text-muted-foreground">Test the offline card management flow (*737#)</p>
        </div>

        {/* Fake Feature Phone */}
        <div className="relative w-[320px] h-[640px] bg-black rounded-[3rem] border-[8px] border-slate-800 shadow-2xl p-4 flex flex-col justify-between">
          
          {/* Status Bar */}
          <div className="flex justify-between items-center text-white/50 px-2 pt-1 pb-2">
            <span className="text-[10px] font-bold">12:30</span>
            <div className="flex gap-1">
              <SignalHigh className="w-3 h-3" />
              <Wifi className="w-3 h-3" />
              <BatteryMedium className="w-3 h-3" />
            </div>
          </div>

          {/* Screen */}
          <div className="w-full h-48 bg-[#9BCC9A] rounded-xl border-4 border-slate-700 p-3 shadow-inner relative flex flex-col">
            {ussdMutation.isPending && (
              <div className="absolute inset-0 bg-[#9BCC9A]/80 flex items-center justify-center z-10 rounded-lg">
                <Loader2 className="w-6 h-6 animate-spin text-black" />
              </div>
            )}
            <pre className="font-mono text-black text-sm whitespace-pre-wrap flex-1 overflow-y-auto leading-relaxed">
              {screenText}
            </pre>
            
            {isSessionActive && (
              <div className="flex items-center border-t border-black/20 pt-2 mt-2">
                <span className="text-black font-mono text-sm pr-2">&gt;</span>
                <input 
                  value={inputText}
                  onChange={e => setInputText(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSend()}
                  className="bg-transparent border-none outline-none text-black font-mono text-sm w-full"
                  autoFocus
                />
              </div>
            )}
          </div>

          {/* Keypad */}
          <div className="flex-1 mt-6 flex flex-col gap-2">
            {!isSessionActive ? (
               <div className="px-2 mb-4">
                <Input 
                  value={inputText}
                  onChange={e => setInputText(e.target.value)}
                  placeholder="*737#"
                  className="bg-white/10 border-white/20 text-center font-mono text-lg text-white rounded-xl h-12"
                />
               </div>
            ) : null}

            <div className="grid grid-cols-3 gap-3 px-4">
              {['1','2','3','4','5','6','7','8','9','*','0','#'].map((key) => (
                <button 
                  key={key}
                  onClick={() => setInputText(prev => prev + key)}
                  className="bg-slate-800 hover:bg-slate-700 active:bg-slate-600 rounded-full h-12 flex items-center justify-center text-white font-bold text-lg transition-colors"
                >
                  {key}
                </button>
              ))}
            </div>

            <div className="flex justify-center mt-4 mb-2">
              <button 
                onClick={handleSend}
                disabled={ussdMutation.isPending}
                className="bg-primary hover:bg-primary/90 active:bg-primary/80 text-white rounded-full w-16 h-16 flex items-center justify-center shadow-lg transition-all"
              >
                <CornerDownLeft className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
