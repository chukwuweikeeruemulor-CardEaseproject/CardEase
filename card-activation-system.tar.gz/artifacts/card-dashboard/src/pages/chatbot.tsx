import { Layout } from "@/components/layout";
import { useChatSessions, useChatMessages, useChatStream } from "@/hooks/use-chat";
import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Send, Bot, User, Loader2, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

const SUGGESTIONS = [
  "How do I activate my new debit card?",
  "I think my card was compromised",
  "How do I increase my daily limit?",
];

export default function Chatbot() {
  const { sessions, createSession } = useChatSessions();
  const [activeSessionId, setActiveSessionId] = useState<number | null>(null);
  
  // Set initial session if loaded and none selected
  useEffect(() => {
    if (sessions.data && sessions.data.length > 0 && !activeSessionId) {
      setActiveSessionId(sessions.data[0].id);
    }
  }, [sessions.data, activeSessionId]);

  const { data: messages, isLoading: messagesLoading } = useChatMessages(activeSessionId || 0);
  const { sendMessage, isStreaming, streamedContent } = useChatStream(activeSessionId);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, streamedContent]);

  const handleCreateNew = async () => {
    const session = await createSession.mutateAsync();
    setActiveSessionId(session.id);
  };

  const handleSend = (content: string) => {
    if (!content.trim() || isStreaming || !activeSessionId) return;
    sendMessage(content);
    setInput("");
  };

  return (
    <Layout>
      <div className="flex flex-col md:flex-row h-[calc(100vh-120px)] gap-6">
        
        {/* Sidebar */}
        <div className="w-full md:w-72 glass-panel rounded-3xl flex flex-col overflow-hidden">
          <div className="p-4 border-b border-border">
            <Button onClick={handleCreateNew} disabled={createSession.isPending} className="w-full bg-primary/20 text-primary hover:bg-primary/30 rounded-xl">
              <Plus className="w-4 h-4 mr-2" /> New Conversation
            </Button>
          </div>
          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            {sessions.isLoading ? (
              <div className="flex justify-center p-4"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
            ) : sessions.data?.map(s => (
              <button
                key={s.id}
                onClick={() => setActiveSessionId(s.id)}
                className={cn(
                  "w-full text-left px-4 py-3 rounded-xl transition-colors truncate text-sm font-medium",
                  activeSessionId === s.id ? "bg-white/10 text-white" : "text-muted-foreground hover:bg-white/5 hover:text-white"
                )}
              >
                {s.title}
              </button>
            ))}
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 glass-panel rounded-3xl flex flex-col overflow-hidden relative">
          {!activeSessionId ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
              <Bot className="w-16 h-16 text-primary/40 mb-4" />
              <h2 className="text-2xl font-bold text-white mb-2">VaultX AI Support</h2>
              <p className="text-muted-foreground max-w-md">Ask me anything about card activation, fraud alerts, or setting up your account.</p>
              <Button onClick={handleCreateNew} className="mt-6 bg-primary text-white rounded-xl">
                Start Chat
              </Button>
            </div>
          ) : (
            <>
              {/* Messages */}
              <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6">
                {messages?.length === 0 && !isStreaming && (
                  <div className="h-full flex flex-col items-center justify-center text-center">
                    <Sparkles className="w-12 h-12 text-primary/40 mb-4" />
                    <p className="text-muted-foreground mb-8">How can I help you today?</p>
                    <div className="flex flex-col gap-2 w-full max-w-sm">
                      {SUGGESTIONS.map(s => (
                        <button 
                          key={s} 
                          onClick={() => handleSend(s)}
                          className="px-4 py-3 text-sm text-white/80 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-colors"
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {messages?.map(m => (
                  <div key={m.id} className={cn("flex gap-4 max-w-[85%]", m.role === "user" ? "ml-auto flex-row-reverse" : "")}>
                    <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center shrink-0", m.role === "user" ? "bg-primary text-white" : "bg-white/10 text-primary")}>
                      {m.role === "user" ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
                    </div>
                    <div className={cn("px-5 py-3 rounded-2xl text-sm leading-relaxed", m.role === "user" ? "bg-primary text-white rounded-tr-sm" : "bg-white/5 border border-white/10 text-white/90 rounded-tl-sm")}>
                      {m.content}
                    </div>
                  </div>
                ))}
                
                {isStreaming && (
                  <div className="flex gap-4 max-w-[85%]">
                     <div className="w-8 h-8 rounded-lg bg-white/10 text-primary flex items-center justify-center shrink-0">
                      <Bot className="w-5 h-5" />
                    </div>
                    <div className="px-5 py-3 rounded-2xl bg-white/5 border border-white/10 text-white/90 rounded-tl-sm text-sm leading-relaxed whitespace-pre-wrap min-w-[60px]">
                      {streamedContent || <span className="animate-pulse">...</span>}
                    </div>
                  </div>
                )}
              </div>

              {/* Input */}
              <div className="p-4 bg-black/20 border-t border-border mt-auto">
                <form 
                  onSubmit={(e) => { e.preventDefault(); handleSend(input); }}
                  className="relative flex items-center max-w-4xl mx-auto"
                >
                  <Input 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Ask about your cards, limits, or security..."
                    className="h-14 pl-6 pr-14 rounded-full bg-white/5 border-white/10 text-white placeholder:text-white/30 focus-visible:ring-primary focus-visible:bg-white/10"
                    disabled={isStreaming}
                  />
                  <Button 
                    type="submit" 
                    size="icon"
                    className="absolute right-2 h-10 w-10 rounded-full bg-primary hover:bg-primary/90 text-white disabled:opacity-50"
                    disabled={!input.trim() || isStreaming}
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </form>
              </div>
            </>
          )}
        </div>
      </div>
    </Layout>
  );
}
