import { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ShieldCheck, Loader2 } from "lucide-react";

const schema = z.object({
  identifier: z.string().min(1, "Phone or email is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export default function Login() {
  const { login } = useAuth();
  const [isPending, setIsPending] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<z.infer<typeof schema>>({
    resolver: zodResolver(schema),
  });

  const onSubmit = async (data: z.infer<typeof schema>) => {
    setIsPending(true);
    try {
      await login(data);
    } catch (e) {
      // Error handled by AuthContext
    } finally {
      setIsPending(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-background">
      {/* Visual Side */}
      <div className="hidden md:flex flex-1 relative items-center justify-center p-12 overflow-hidden">
        <img 
          src={`${import.meta.env.BASE_URL}images/auth-bg.png`} 
          alt="Premium Fintech Background" 
          className="absolute inset-0 w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background to-transparent" />
        
        <div className="relative z-10 max-w-lg">
          <div className="flex items-center gap-3 mb-6">
            <img src={`${import.meta.env.BASE_URL}images/logo-icon.png`} alt="Logo" className="w-12 h-12 rounded-xl" />
            <h1 className="font-display text-4xl font-bold text-white">Vault<span className="text-primary">X</span></h1>
          </div>
          <h2 className="text-4xl font-bold text-white mb-4 leading-tight">
            Secure Digital ATM <br/>Card Activation.
          </h2>
          <p className="text-lg text-white/70">
            Manage your virtual and physical cards securely. No physical ATM visit required. Next-gen fraud protection built-in.
          </p>
        </div>
      </div>

      {/* Form Side */}
      <div className="flex-1 flex items-center justify-center p-6 md:p-12 relative z-10">
        <div className="w-full max-w-md glass-panel p-8 rounded-3xl">
          <div className="md:hidden flex items-center gap-2 mb-8">
            <img src={`${import.meta.env.BASE_URL}images/logo-icon.png`} alt="Logo" className="w-8 h-8 rounded-lg" />
            <span className="font-display font-bold text-2xl text-white">Vault<span className="text-primary">X</span></span>
          </div>

          <div className="mb-8 text-center md:text-left">
            <h3 className="text-2xl font-bold text-white mb-2">Welcome back</h3>
            <p className="text-muted-foreground">Sign in to manage your cards</p>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="identifier" className="text-white/80">Email or Phone</Label>
              <Input 
                id="identifier" 
                placeholder="john@example.com or +234..." 
                className="bg-black/20 border-white/10 h-12 rounded-xl text-white placeholder:text-white/30 focus-visible:ring-primary"
                {...register("identifier")}
              />
              {errors.identifier && <p className="text-red-400 text-sm">{errors.identifier.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-white/80">Password</Label>
              <Input 
                id="password" 
                type="password" 
                placeholder="••••••••" 
                className="bg-black/20 border-white/10 h-12 rounded-xl text-white placeholder:text-white/30 focus-visible:ring-primary"
                {...register("password")}
              />
              {errors.password && <p className="text-red-400 text-sm">{errors.password.message}</p>}
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 rounded-xl text-base font-semibold bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/25"
              disabled={isPending}
            >
              {isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : "Sign In"}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-muted-foreground">
              Don't have an account?{" "}
              <Link href="/auth/register" className="text-primary font-medium hover:underline">
                Create one
              </Link>
            </p>
          </div>

          <div className="mt-8 flex items-center justify-center gap-2 text-xs text-white/40">
            <ShieldCheck className="w-4 h-4" />
            Secured by AES-256 Encryption
          </div>
        </div>
      </div>
    </div>
  );
}
