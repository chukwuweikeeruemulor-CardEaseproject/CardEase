import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useOtp } from "@/hooks/use-otp";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, ArrowRight, CheckCircle2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const registerSchema = z.object({
  firstName: z.string().min(1, "First name required"),
  lastName: z.string().min(1, "Last name required"),
  email: z.string().email("Valid email required"),
  phone: z.string().min(10, "Phone number required"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  bvn: z.string().optional(),
});

const otpSchema = z.object({
  otp: z.string().length(6, "OTP must be 6 digits")
});

export default function Register() {
  const { register: registerUser } = useAuth();
  const { sendOtp, verifyOtp } = useOtp();
  const [, setLocation] = useLocation();
  
  const [step, setStep] = useState<"details" | "otp">("details");
  const [identifier, setIdentifier] = useState("");
  
  const form = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
  });

  const otpForm = useForm<z.infer<typeof otpSchema>>({
    resolver: zodResolver(otpSchema),
  });

  const onRegisterSubmit = async (data: z.infer<typeof registerSchema>) => {
    try {
      await registerUser(data);
      setIdentifier(data.email);
      await sendOtp.mutateAsync({
        data: {
          destination: data.email,
          channel: "email",
          purpose: "registration"
        }
      });
      setStep("otp");
    } catch (e) {
      // Handled by context
    }
  };

  const onOtpSubmit = async (data: z.infer<typeof otpSchema>) => {
    try {
      await verifyOtp.mutateAsync({
        data: {
          destination: identifier,
          otp: data.otp,
          purpose: "registration"
        }
      });
      setLocation("/");
    } catch (e) {
      // Error handled by mutation toast
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] right-[-5%] w-[40%] h-[40%] rounded-full bg-primary/20 blur-[120px]" />
        <div className="absolute bottom-[-10%] left-[-5%] w-[40%] h-[40%] rounded-full bg-accent/10 blur-[120px]" />
      </div>

      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <img src={`${import.meta.env.BASE_URL}images/logo-icon.png`} alt="Logo" className="w-12 h-12 rounded-xl mx-auto mb-4" />
          <h1 className="font-display text-3xl font-bold text-white mb-2">Create Account</h1>
          <p className="text-muted-foreground">Join VaultX to manage your cards</p>
        </div>

        <div className="glass-panel p-8 rounded-3xl">
          <AnimatePresence mode="wait">
            {step === "details" && (
              <motion.div
                key="details"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
              >
                <form onSubmit={form.handleSubmit(onRegisterSubmit)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-white/80">First Name</Label>
                      <Input 
                        {...form.register("firstName")}
                        className="bg-black/20 border-white/10 rounded-xl" 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-white/80">Last Name</Label>
                      <Input 
                        {...form.register("lastName")}
                        className="bg-black/20 border-white/10 rounded-xl" 
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-white/80">Email</Label>
                    <Input 
                      type="email"
                      {...form.register("email")}
                      className="bg-black/20 border-white/10 rounded-xl" 
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-white/80">Phone Number</Label>
                    <Input 
                      {...form.register("phone")}
                      className="bg-black/20 border-white/10 rounded-xl" 
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-white/80">Password</Label>
                    <Input 
                      type="password"
                      {...form.register("password")}
                      className="bg-black/20 border-white/10 rounded-xl" 
                    />
                    {form.formState.errors.password && (
                      <p className="text-red-400 text-xs">{form.formState.errors.password.message}</p>
                    )}
                  </div>

                  <div className="space-y-2 pt-2">
                    <Label className="text-white/80 flex items-center gap-2">
                      BVN <span className="text-xs text-white/40">(Optional for now)</span>
                    </Label>
                    <Input 
                      {...form.register("bvn")}
                      className="bg-black/20 border-white/10 rounded-xl" 
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full h-12 mt-6 rounded-xl bg-primary hover:bg-primary/90 text-white font-semibold flex items-center gap-2 group"
                    disabled={form.formState.isSubmitting}
                  >
                    {form.formState.isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : "Continue"}
                    {!form.formState.isSubmitting && <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />}
                  </Button>
                </form>
              </motion.div>
            )}

            {step === "otp" && (
              <motion.div
                key="otp"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="text-center"
              >
                <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle2 className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Verify your email</h3>
                <p className="text-muted-foreground mb-8">
                  We sent a 6-digit code to <br/><span className="text-white">{identifier}</span>
                </p>

                <form onSubmit={otpForm.handleSubmit(onOtpSubmit)} className="space-y-6">
                  <div className="space-y-2 text-left">
                    <Label className="text-white/80">Enter OTP</Label>
                    <Input 
                      {...otpForm.register("otp")}
                      placeholder="000000"
                      maxLength={6}
                      className="bg-black/20 border-white/10 h-14 rounded-xl text-center text-2xl tracking-widest text-white font-mono" 
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full h-12 rounded-xl bg-primary hover:bg-primary/90 text-white font-semibold"
                    disabled={verifyOtp.isPending}
                  >
                    {verifyOtp.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : "Verify & Complete"}
                  </Button>
                </form>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        
        {step === "details" && (
          <div className="mt-6 text-center">
            <p className="text-muted-foreground text-sm">
              Already have an account?{" "}
              <Link href="/auth/login" className="text-primary font-medium hover:underline">
                Sign in
              </Link>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
