import { useState } from "react";
import { Layout } from "@/components/layout";
import { useCard, useActivateNewCard, useSetCardPin } from "@/hooks/use-cards";
import { useOtp } from "@/hooks/use-otp";
import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, ShieldCheck, CheckCircle2 } from "lucide-react";
import { VisualCard } from "@/components/visual-card";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "@/hooks/use-toast";

export default function ActivateCard() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { data: card, isLoading } = useCard(Number(id));
  const { sendOtp, verifyOtp } = useOtp();
  const activateMutation = useActivateNewCard();
  const setPinMutation = useSetCardPin();

  const [step, setStep] = useState<"init" | "otp" | "pin" | "success">("init");
  const [otpToken, setOtpToken] = useState<string>("");
  const [otpCode, setOtpCode] = useState("");
  const [pinCode, setPinCode] = useState("");

  if (isLoading || !card) return <Layout><div className="flex justify-center p-20"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div></Layout>;

  if (card.status !== "pending" && step !== "success") {
    return (
      <Layout>
        <div className="glass-panel p-12 text-center max-w-lg mx-auto rounded-3xl mt-12">
          <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Card Already Active</h2>
          <p className="text-muted-foreground mb-6">This card is already activated and ready to use.</p>
          <Button onClick={() => setLocation(`/cards/${card.id}`)} className="bg-white/10 hover:bg-white/20 text-white">
            Go to Card Settings
          </Button>
        </div>
      </Layout>
    );
  }

  const handleStart = async () => {
    try {
      await sendOtp.mutateAsync({
        data: {
          destination: "user-email", // In real app, pulled from profile or auth context
          channel: "email",
          purpose: "card_activation"
        }
      });
      setStep("otp");
    } catch (e) {
      toast({ title: "Error", description: "Failed to send OTP", variant: "destructive" });
    }
  };

  const handleVerifyOtp = async () => {
    try {
      const res = await verifyOtp.mutateAsync({
        data: {
          destination: "user-email",
          otp: otpCode,
          purpose: "card_activation"
        }
      });
      if (res.token) {
        setOtpToken(res.token);
        setStep("pin");
      }
    } catch (e) {}
  };

  const handleSetPinAndActivate = async () => {
    try {
      // 1. Set PIN
      await setPinMutation.mutateAsync({
        id: card.id,
        data: { pin: pinCode, otpToken }
      });
      
      // 2. Activate Card
      await activateMutation.mutateAsync({
        id: card.id,
        data: { otpToken }
      });

      setStep("success");
    } catch (e) {}
  };

  return (
    <Layout>
      <div className="max-w-2xl mx-auto mt-4 md:mt-12">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold text-white mb-2">Secure Activation</h1>
          <p className="text-muted-foreground">Activate your card digitally without visiting an ATM.</p>
        </div>

        <div className="mb-10 w-full max-w-sm mx-auto">
          <VisualCard card={card} />
        </div>

        <div className="glass-panel p-8 rounded-3xl relative overflow-hidden">
          <AnimatePresence mode="wait">
            {step === "init" && (
              <motion.div key="init" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="text-center">
                  <ShieldCheck className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-white mb-2">Verify Identity</h3>
                  <p className="text-muted-foreground mb-8">We'll send a one-time code to your registered email to ensure it's really you.</p>
                  <Button onClick={handleStart} disabled={sendOtp.isPending} className="w-full h-12 bg-primary text-white text-lg rounded-xl">
                    {sendOtp.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : "Send Code"}
                  </Button>
                </div>
              </motion.div>
            )}

            {step === "otp" && (
              <motion.div key="otp" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                <div className="text-center">
                  <h3 className="text-xl font-bold text-white mb-2">Enter Verification Code</h3>
                  <p className="text-muted-foreground mb-8">Check your email for the 6-digit code.</p>
                  <div className="space-y-6">
                    <Input 
                      value={otpCode}
                      onChange={e => setOtpCode(e.target.value)}
                      placeholder="000000"
                      maxLength={6}
                      className="bg-black/20 border-white/10 h-16 rounded-xl text-center text-3xl tracking-[0.5em] text-white font-mono max-w-[240px] mx-auto" 
                    />
                    <Button 
                      onClick={handleVerifyOtp} 
                      disabled={verifyOtp.isPending || otpCode.length !== 6} 
                      className="w-full h-12 bg-primary text-white text-lg rounded-xl"
                    >
                      {verifyOtp.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : "Verify"}
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}

            {step === "pin" && (
              <motion.div key="pin" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                <div className="text-center">
                  <h3 className="text-xl font-bold text-white mb-2">Create Card PIN</h3>
                  <p className="text-muted-foreground mb-8">Set a 4-digit PIN for ATM and POS transactions.</p>
                  <div className="space-y-6">
                    <Input 
                      type="password"
                      value={pinCode}
                      onChange={e => setPinCode(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="••••"
                      maxLength={4}
                      className="bg-black/20 border-white/10 h-16 rounded-xl text-center text-4xl tracking-[0.5em] text-white font-mono max-w-[200px] mx-auto" 
                    />
                    <Button 
                      onClick={handleSetPinAndActivate} 
                      disabled={setPinMutation.isPending || activateMutation.isPending || pinCode.length !== 4} 
                      className="w-full h-12 bg-primary text-white text-lg rounded-xl"
                    >
                      {(setPinMutation.isPending || activateMutation.isPending) ? <Loader2 className="w-5 h-5 animate-spin" /> : "Activate Card"}
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}

            {step === "success" && (
              <motion.div key="success" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
                <div className="text-center">
                  <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle2 className="w-10 h-10 text-green-500" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">Card Activated!</h3>
                  <p className="text-muted-foreground mb-8">Your card is now ready to use for all transactions.</p>
                  <Button onClick={() => setLocation(`/cards/${card.id}`)} className="w-full h-12 bg-white/10 hover:bg-white/20 text-white rounded-xl">
                    Manage Card
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </Layout>
  );
}
