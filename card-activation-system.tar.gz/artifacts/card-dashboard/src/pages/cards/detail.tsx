import { Layout } from "@/components/layout";
import { useCard, useToggleCardBlock, useUpdateLimits } from "@/hooks/use-cards";
import { useParams, Link, useLocation } from "wouter";
import { VisualCard } from "@/components/visual-card";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Loader2, ArrowLeft, ShieldAlert, LockOpen, Wifi, Globe, ShoppingBag, Settings2 } from "lucide-react";
import { useState, useEffect } from "react";
import { formatCurrency } from "@/lib/utils";

export default function CardDetail() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { data: card, isLoading } = useCard(Number(id));
  const { blockMutation, unblockMutation } = useToggleCardBlock();
  const updateLimits = useUpdateLimits();

  // Local state for optimistic UI updates before saving
  const [dailyLimit, setDailyLimit] = useState<number>(0);
  const [monthlyLimit, setMonthlyLimit] = useState<number>(0);

  useEffect(() => {
    if (card) {
      setDailyLimit(card.dailyLimit);
      setMonthlyLimit(card.monthlyLimit);
    }
  }, [card]);

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
      </Layout>
    );
  }

  if (!card) {
    return (
      <Layout>
        <div className="text-center py-20 text-white">Card not found.</div>
      </Layout>
    );
  }

  const isBlocked = card.status === "blocked";
  const isPending = card.status === "pending";

  const handleToggleState = async (field: string, value: boolean) => {
    try {
      await updateLimits.mutateAsync({
        id: card.id,
        data: { [field]: value }
      });
    } catch (e) {
      // Revert handled by react-query error logic typically
    }
  };

  const handleSaveLimits = async () => {
    await updateLimits.mutateAsync({
      id: card.id,
      data: { dailyLimit, monthlyLimit }
    });
  };

  const toggleBlock = async () => {
    if (isBlocked) {
      await unblockMutation.mutateAsync({ id: card.id });
    } else {
      await blockMutation.mutateAsync({ id: card.id, data: { reason: "User requested block from dashboard" } });
    }
  };

  return (
    <Layout>
      <Link href="/cards" className="inline-flex items-center text-muted-foreground hover:text-white mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4 mr-2" /> Back to Cards
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column - The Card */}
        <div className="lg:col-span-4 space-y-6">
          <VisualCard card={card} />
          
          {isPending && (
            <div className="glass-panel p-6 rounded-2xl border-yellow-500/20 bg-yellow-500/5">
              <h3 className="font-bold text-yellow-500 mb-2">Activation Required</h3>
              <p className="text-sm text-yellow-200/70 mb-4">You need to verify OTP and set a PIN to start using this card.</p>
              <Button onClick={() => setLocation(`/activate/${card.id}`)} className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-bold">
                Activate Card
              </Button>
            </div>
          )}

          <div className="glass-panel p-6 rounded-2xl">
            <h3 className="font-bold text-white mb-4 flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-primary" /> Card Security
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-medium">Freeze Card</p>
                  <p className="text-xs text-muted-foreground">Temporarily block all transactions</p>
                </div>
                <Switch 
                  checked={isBlocked}
                  onCheckedChange={toggleBlock}
                  disabled={blockMutation.isPending || unblockMutation.isPending}
                  className="data-[state=checked]:bg-red-500"
                />
              </div>

              {!isBlocked && (
                <div className="pt-4 border-t border-white/5">
                  <Button variant="outline" className="w-full border-white/10 hover:bg-white/5 text-white">
                    Reset PIN
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column - Controls */}
        <div className="lg:col-span-8 space-y-6">
          <div className="glass-panel p-6 md:p-8 rounded-3xl">
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              <Settings2 className="w-6 h-6 text-primary" /> Transaction Controls
            </h2>
            
            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 rounded-2xl bg-white/5">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-blue-500/10 rounded-xl text-blue-400"><Globe className="w-5 h-5" /></div>
                  <div>
                    <p className="text-white font-medium">International Usage</p>
                    <p className="text-sm text-muted-foreground">Allow transactions outside your home country</p>
                  </div>
                </div>
                <Switch 
                  checked={card.isInternationalEnabled}
                  onCheckedChange={(v) => handleToggleState('isInternationalEnabled', v)}
                  disabled={updateLimits.isPending}
                />
              </div>

              <div className="flex items-center justify-between p-4 rounded-2xl bg-white/5">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-purple-500/10 rounded-xl text-purple-400"><ShoppingBag className="w-5 h-5" /></div>
                  <div>
                    <p className="text-white font-medium">Online Transactions</p>
                    <p className="text-sm text-muted-foreground">E-commerce and app purchases</p>
                  </div>
                </div>
                <Switch 
                  checked={card.isOnlineEnabled}
                  onCheckedChange={(v) => handleToggleState('isOnlineEnabled', v)}
                  disabled={updateLimits.isPending}
                />
              </div>

              <div className="flex items-center justify-between p-4 rounded-2xl bg-white/5">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-emerald-500/10 rounded-xl text-emerald-400"><Wifi className="w-5 h-5" /></div>
                  <div>
                    <p className="text-white font-medium">Contactless Payments</p>
                    <p className="text-sm text-muted-foreground">Tap to pay at physical terminals</p>
                  </div>
                </div>
                <Switch 
                  checked={card.isContactless}
                  onCheckedChange={(v) => handleToggleState('isContactless', v)}
                  disabled={updateLimits.isPending}
                />
              </div>
            </div>
          </div>

          <div className="glass-panel p-6 md:p-8 rounded-3xl">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-xl font-bold text-white">Spending Limits</h2>
              {(dailyLimit !== card.dailyLimit || monthlyLimit !== card.monthlyLimit) && (
                <Button 
                  size="sm" 
                  onClick={handleSaveLimits}
                  disabled={updateLimits.isPending}
                  className="bg-primary text-white"
                >
                  {updateLimits.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Save Changes"}
                </Button>
              )}
            </div>

            <div className="space-y-8">
              <div>
                <div className="flex justify-between items-end mb-4">
                  <div>
                    <p className="text-white font-medium">Daily Limit</p>
                    <p className="text-sm text-muted-foreground">Max spending per day</p>
                  </div>
                  <div className="text-xl font-display font-bold text-primary">{formatCurrency(dailyLimit)}</div>
                </div>
                <Slider 
                  value={[dailyLimit]} 
                  min={0} 
                  max={10000} 
                  step={100}
                  onValueChange={(v) => setDailyLimit(v[0])}
                  className="py-2"
                />
              </div>

              <div>
                <div className="flex justify-between items-end mb-4">
                  <div>
                    <p className="text-white font-medium">Monthly Limit</p>
                    <p className="text-sm text-muted-foreground">Max spending per calendar month</p>
                  </div>
                  <div className="text-xl font-display font-bold text-primary">{formatCurrency(monthlyLimit)}</div>
                </div>
                <Slider 
                  value={[monthlyLimit]} 
                  min={0} 
                  max={50000} 
                  step={500}
                  onValueChange={(v) => setMonthlyLimit(v[0])}
                  className="py-2"
                />
              </div>
            </div>
          </div>

        </div>
      </div>
    </Layout>
  );
}
