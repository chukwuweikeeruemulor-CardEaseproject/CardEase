import { useState } from "react";
import { Layout } from "@/components/layout";
import { useCards, useLinkNewCard } from "@/hooks/use-cards";
import { VisualCard } from "@/components/visual-card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Plus, CreditCard, ShieldCheck, Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

const linkSchema = z.object({
  cardNumber: z.string().min(16).max(19),
  cardholderName: z.string().min(1),
  cardType: z.enum(["debit", "virtual", "credit"]),
  expiryMonth: z.coerce.number().min(1).max(12),
  expiryYear: z.coerce.number().min(2023).max(2040),
});

export default function CardsList() {
  const { data: cards, isLoading } = useCards();
  const linkCard = useLinkNewCard();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { register, handleSubmit, setValue, formState: { isSubmitting } } = useForm<z.infer<typeof linkSchema>>({
    resolver: zodResolver(linkSchema),
    defaultValues: {
      cardType: "debit"
    }
  });

  const onSubmit = async (data: z.infer<typeof linkSchema>) => {
    try {
      await linkCard.mutateAsync({ data });
      setIsDialogOpen(false);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <Layout>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white">My Cards</h1>
          <p className="text-muted-foreground mt-1">Manage your linked and virtual cards.</p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 text-white font-medium rounded-xl h-11 px-6 shadow-lg shadow-primary/20">
              <Plus className="w-5 h-5 mr-2" />
              Link New Card
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle className="text-xl text-white">Link a Card</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label className="text-white/80">Card Number</Label>
                <Input {...register("cardNumber")} placeholder="1234 5678 9012 3456" className="bg-black/20 border-white/10" />
              </div>
              <div className="space-y-2">
                <Label className="text-white/80">Cardholder Name</Label>
                <Input {...register("cardholderName")} placeholder="JOHN DOE" className="bg-black/20 border-white/10 uppercase" />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-white/80">Expiry Month</Label>
                  <Input {...register("expiryMonth")} placeholder="MM" type="number" className="bg-black/20 border-white/10" />
                </div>
                <div className="space-y-2">
                  <Label className="text-white/80">Expiry Year</Label>
                  <Input {...register("expiryYear")} placeholder="YYYY" type="number" className="bg-black/20 border-white/10" />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-white/80">Card Type</Label>
                <Select onValueChange={(v) => setValue("cardType", v as any)} defaultValue="debit">
                  <SelectTrigger className="bg-black/20 border-white/10 text-white">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border text-white">
                    <SelectItem value="debit">Debit Card</SelectItem>
                    <SelectItem value="virtual">Virtual Card</SelectItem>
                    <SelectItem value="credit">Credit Card</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button type="submit" disabled={isSubmitting} className="w-full h-11 mt-4 bg-primary text-white">
                {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : "Link Securely"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-64 bg-white/5 animate-pulse rounded-3xl" />
          ))}
        </div>
      ) : cards && cards.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {cards.map(card => (
            <div key={card.id} className="group relative">
              <Link href={`/cards/${card.id}`} className="block h-full cursor-pointer">
                <VisualCard card={card} className="group-hover:shadow-2xl group-hover:shadow-primary/10" />
              </Link>
              
              {/* Quick Action Overlay */}
              <div className="absolute -bottom-4 inset-x-8 opacity-0 group-hover:opacity-100 group-hover:bottom-[-20px] transition-all duration-300 z-20 flex justify-center pointer-events-none">
                <div className="glass-panel px-4 py-2 rounded-full flex gap-4 pointer-events-auto">
                  {card.status === 'pending' ? (
                    <Link href={`/activate/${card.id}`}>
                      <button className="text-xs font-bold text-yellow-400 hover:text-yellow-300 uppercase tracking-wide">
                        Activate Now
                      </button>
                    </Link>
                  ) : (
                    <Link href={`/cards/${card.id}`}>
                      <button className="text-xs font-bold text-white hover:text-primary uppercase tracking-wide flex items-center gap-1">
                        Manage Settings
                      </button>
                    </Link>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="glass-panel p-16 flex flex-col items-center justify-center text-center rounded-3xl border-dashed max-w-2xl mx-auto mt-12">
          <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-6">
            <CreditCard className="w-10 h-10 text-white/30" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-3">No cards found</h2>
          <p className="text-muted-foreground mb-8 max-w-md">
            You don't have any physical or virtual cards linked to your VaultX account yet.
          </p>
          <Button onClick={() => setIsDialogOpen(true)} className="bg-primary text-white h-12 px-8 rounded-xl">
            <Plus className="w-5 h-5 mr-2" />
            Link Your First Card
          </Button>
          
          <div className="mt-12 flex items-center gap-2 text-sm text-white/40">
            <ShieldCheck className="w-4 h-4" /> PCI-DSS Compliant Storage
          </div>
        </div>
      )}
    </Layout>
  );
}
