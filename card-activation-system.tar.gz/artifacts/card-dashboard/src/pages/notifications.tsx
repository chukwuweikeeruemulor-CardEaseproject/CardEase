import { Layout } from "@/components/layout";
import { useNotificationsHistory, useNotificationPrefs } from "@/hooks/use-notifications";
import { Switch } from "@/components/ui/switch";
import { Bell, Smartphone, Mail, ShieldAlert, CreditCard, Tag } from "lucide-react";
import { format } from "date-fns";

export default function Notifications() {
  const { data: history, isLoading: historyLoading } = useNotificationsHistory();
  const { prefsQuery, updatePrefs } = useNotificationPrefs();
  const prefs = prefsQuery.data;

  const handlePrefChange = (key: string, value: boolean) => {
    if (!prefs) return;
    updatePrefs.mutate({
      data: { ...prefs, [key]: value }
    });
  };

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white flex items-center gap-3">
          <Bell className="w-8 h-8 text-primary" /> Notifications
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          <h2 className="text-xl font-bold text-white mb-4">Recent Alerts</h2>
          
          {historyLoading ? (
            [1,2,3].map(i => <div key={i} className="h-20 bg-white/5 animate-pulse rounded-2xl" />)
          ) : history?.length === 0 ? (
            <div className="glass-panel p-12 text-center rounded-3xl border-dashed">
              <Bell className="w-12 h-12 text-white/20 mx-auto mb-4" />
              <p className="text-muted-foreground">You have no notifications right now.</p>
            </div>
          ) : (
            history?.map(note => (
              <div key={note.id} className="glass-panel p-5 rounded-2xl flex gap-4">
                <div className="w-2 h-2 mt-2 rounded-full bg-primary shrink-0" />
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-bold text-white text-base">{note.title}</h4>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-white/10 text-white/60 uppercase">{note.channel}</span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{note.body}</p>
                  <p className="text-[10px] text-white/30 uppercase tracking-wider">{format(new Date(note.createdAt), "MMM d, h:mm a")}</p>
                </div>
              </div>
            ))
          )}
        </div>

        <div>
          <div className="glass-panel p-6 rounded-3xl sticky top-24">
            <h2 className="text-xl font-bold text-white mb-6">Preferences</h2>
            
            {prefsQuery.isLoading ? (
              <div className="space-y-4">
                {[1,2,3].map(i => <div key={i} className="h-12 bg-white/5 animate-pulse rounded-xl" />)}
              </div>
            ) : prefs && (
              <div className="space-y-8">
                <div className="space-y-4">
                  <h3 className="text-xs font-bold text-white/40 uppercase tracking-widest mb-3">Channels</h3>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Smartphone className="w-4 h-4 text-primary" />
                      <span className="text-sm font-medium text-white/90">SMS Alerts</span>
                    </div>
                    <Switch checked={prefs.smsEnabled} onCheckedChange={(v) => handlePrefChange('smsEnabled', v)} />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Mail className="w-4 h-4 text-primary" />
                      <span className="text-sm font-medium text-white/90">Email Reports</span>
                    </div>
                    <Switch checked={prefs.emailEnabled} onCheckedChange={(v) => handlePrefChange('emailEnabled', v)} />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Bell className="w-4 h-4 text-primary" />
                      <span className="text-sm font-medium text-white/90">Push Notifications</span>
                    </div>
                    <Switch checked={prefs.pushEnabled} onCheckedChange={(v) => handlePrefChange('pushEnabled', v)} />
                  </div>
                </div>

                <div className="space-y-4 pt-6 border-t border-white/5">
                  <h3 className="text-xs font-bold text-white/40 uppercase tracking-widest mb-3">Topics</h3>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <CreditCard className="w-4 h-4 text-emerald-400" />
                      <span className="text-sm font-medium text-white/90">Transactions</span>
                    </div>
                    <Switch checked={prefs.transactionAlerts} onCheckedChange={(v) => handlePrefChange('transactionAlerts', v)} />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <ShieldAlert className="w-4 h-4 text-red-400" />
                      <span className="text-sm font-medium text-white/90">Security</span>
                    </div>
                    <Switch checked={prefs.securityAlerts} onCheckedChange={(v) => handlePrefChange('securityAlerts', v)} />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Tag className="w-4 h-4 text-purple-400" />
                      <span className="text-sm font-medium text-white/90">Marketing</span>
                    </div>
                    <Switch checked={prefs.marketingAlerts} onCheckedChange={(v) => handlePrefChange('marketingAlerts', v)} />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
