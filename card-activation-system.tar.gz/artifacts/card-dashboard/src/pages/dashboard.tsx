import { useAuth } from "@/hooks/use-auth";
import { useCards } from "@/hooks/use-cards";
import { useFraudAlerts } from "@/hooks/use-fraud";
import { Layout } from "@/components/layout";
import { VisualCard } from "@/components/visual-card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowUpRight, ShieldAlert, Plus, RefreshCw, CreditCard, Clock } from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import { format } from "date-fns";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: cards, isLoading: cardsLoading } = useCards();
  const { data: alerts } = useFraudAlerts();

  const activeCards = cards?.filter(c => c.status === "active") || [];
  const openAlerts = alerts?.filter(a => a.status === "open") || [];
  
  // Fake balance calculation for demo
  const totalBalance = activeCards.reduce((acc, card) => acc + (card.monthlyLimit * 0.45), 0) || 12450.00;

  return (
    <Layout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white">Dashboard</h1>
            <p className="text-muted-foreground mt-1">Welcome back, {user?.firstName}. Here's what's happening.</p>
          </div>
          <div className="flex gap-3">
            <Link href="/cards">
              <Button className="bg-white/10 hover:bg-white/20 text-white border-0">
                <CreditCard className="w-4 h-4 mr-2" />
                Manage Cards
              </Button>
            </Link>
            <Link href="/cards">
              <Button className="bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/20">
                <Plus className="w-4 h-4 mr-2" />
                Link New Card
              </Button>
            </Link>
          </div>
        </div>

        {/* Top Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="glass-panel p-6 rounded-2xl">
            <div className="flex justify-between items-start mb-4">
              <div className="p-3 bg-primary/20 rounded-xl">
                <CircleDollarSignIcon className="w-6 h-6 text-primary" />
              </div>
              <span className="text-xs font-medium text-emerald-400 bg-emerald-400/10 px-2 py-1 rounded-md flex items-center gap-1">
                <ArrowUpRight className="w-3 h-3" /> +2.4%
              </span>
            </div>
            <p className="text-muted-foreground text-sm font-medium mb-1">Total Limit Available</p>
            <h3 className="text-3xl font-display font-bold text-white">{formatCurrency(totalBalance)}</h3>
          </div>

          <div className="glass-panel p-6 rounded-2xl">
            <div className="flex justify-between items-start mb-4">
              <div className="p-3 bg-accent/20 rounded-xl">
                <CreditCard className="w-6 h-6 text-accent" />
              </div>
            </div>
            <p className="text-muted-foreground text-sm font-medium mb-1">Active Cards</p>
            <h3 className="text-3xl font-display font-bold text-white">{activeCards.length}</h3>
          </div>

          <div className="glass-panel p-6 rounded-2xl relative overflow-hidden">
            {openAlerts.length > 0 && (
              <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/20 blur-3xl rounded-full" />
            )}
            <div className="flex justify-between items-start mb-4 relative z-10">
              <div className="p-3 bg-red-500/20 rounded-xl">
                <ShieldAlert className="w-6 h-6 text-red-400" />
              </div>
            </div>
            <p className="text-muted-foreground text-sm font-medium mb-1">Security Alerts</p>
            <div className="flex items-baseline gap-3 relative z-10">
              <h3 className="text-3xl font-display font-bold text-white">{openAlerts.length}</h3>
              {openAlerts.length > 0 && (
                <Link href="/fraud" className="text-sm text-red-400 hover:underline">Requires attention</Link>
              )}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Cards View */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-white">Your Cards</h2>
              <Link href="/cards" className="text-sm text-primary hover:underline font-medium">View all</Link>
            </div>
            
            {cardsLoading ? (
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="h-48 bg-white/5 animate-pulse rounded-2xl"></div>
                <div className="h-48 bg-white/5 animate-pulse rounded-2xl hidden sm:block"></div>
              </div>
            ) : cards && cards.length > 0 ? (
              <div className="grid sm:grid-cols-2 gap-6">
                {cards.slice(0, 2).map((card) => (
                  <Link key={card.id} href={`/cards/${card.id}`} className="block group">
                    <div className="transition-transform duration-300 group-hover:-translate-y-1">
                      <VisualCard card={card} />
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="glass-panel p-12 text-center rounded-3xl border-dashed">
                <CreditCard className="w-12 h-12 text-white/20 mx-auto mb-4" />
                <h3 className="text-lg font-bold text-white mb-2">No cards linked</h3>
                <p className="text-muted-foreground mb-6">Link a physical debit card or generate a virtual card instantly.</p>
                <Link href="/cards">
                  <Button className="bg-primary text-white">Link a Card</Button>
                </Link>
              </div>
            )}
          </div>

          {/* Side panel */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-white">Quick Actions</h2>
            <div className="glass-panel p-2 rounded-2xl flex flex-col gap-2">
              <Link href="/cards">
                <div className="flex items-center gap-4 p-4 rounded-xl hover:bg-white/5 cursor-pointer transition-colors">
                  <div className="p-3 rounded-full bg-blue-500/10 text-blue-400"><RefreshCw className="w-5 h-5" /></div>
                  <div>
                    <h4 className="text-white font-medium">Activate Card</h4>
                    <p className="text-xs text-muted-foreground">Verify OTP to activate physical card</p>
                  </div>
                </div>
              </Link>
              <div className="h-px bg-border mx-4" />
              <Link href="/fraud">
                <div className="flex items-center gap-4 p-4 rounded-xl hover:bg-white/5 cursor-pointer transition-colors">
                  <div className="p-3 rounded-full bg-red-500/10 text-red-400"><ShieldAlert className="w-5 h-5" /></div>
                  <div>
                    <h4 className="text-white font-medium">Report Fraud</h4>
                    <p className="text-xs text-muted-foreground">Lock card and file dispute</p>
                  </div>
                </div>
              </Link>
            </div>

            <div className="glass-panel p-6 rounded-2xl">
              <h3 className="font-bold text-white mb-4">Recent Activity</h3>
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="flex items-start gap-3">
                    <div className="mt-0.5"><Clock className="w-4 h-4 text-muted-foreground" /></div>
                    <div>
                      <p className="text-sm text-white font-medium">Card limits updated</p>
                      <p className="text-xs text-muted-foreground">Today at 10:42 AM</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

// Minimal icon component
function CircleDollarSignIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8" />
      <path d="M12 18V6" />
    </svg>
  );
}
