import { Layout } from "@/components/layout";
import { useFraudAlerts, useResolveAlert } from "@/hooks/use-fraud";
import { Button } from "@/components/ui/button";
import { ShieldAlert, CheckCircle2, AlertTriangle, MapPin, CreditCard, Activity } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

export default function FraudAlerts() {
  const { data: alerts, isLoading } = useFraudAlerts();
  const resolveMutation = useResolveAlert();

  const handleResolve = async (id: number) => {
    await resolveMutation.mutateAsync({ id });
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical": return "text-red-500 bg-red-500/10 border-red-500/20";
      case "high": return "text-orange-500 bg-orange-500/10 border-orange-500/20";
      case "medium": return "text-yellow-500 bg-yellow-500/10 border-yellow-500/20";
      default: return "text-blue-400 bg-blue-500/10 border-blue-500/20";
    }
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "unusual_location": return <MapPin className="w-5 h-5" />;
      case "high_amount": return <CreditCard className="w-5 h-5" />;
      case "velocity_check": return <Activity className="w-5 h-5" />;
      default: return <AlertTriangle className="w-5 h-5" />;
    }
  };

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white flex items-center gap-3">
          <ShieldAlert className="w-8 h-8 text-primary" /> Fraud Detection
        </h1>
        <p className="text-muted-foreground mt-2">AI-powered security monitoring for all your linked cards.</p>
      </div>

      <div className="space-y-4">
        {isLoading ? (
          [1, 2, 3].map(i => <div key={i} className="h-32 bg-white/5 animate-pulse rounded-2xl" />)
        ) : alerts?.length === 0 ? (
          <div className="glass-panel p-12 text-center rounded-3xl border-dashed">
            <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-8 h-8 text-green-500" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">All Clear</h3>
            <p className="text-muted-foreground">No suspicious activities detected on your accounts.</p>
          </div>
        ) : (
          alerts?.map(alert => {
            const isOpen = alert.status === "open";
            return (
              <div key={alert.id} className={cn("glass-panel p-6 rounded-2xl flex flex-col md:flex-row gap-6 justify-between items-start md:items-center transition-all", !isOpen && "opacity-60")}>
                <div className="flex gap-4">
                  <div className={cn("p-4 rounded-xl shrink-0 h-fit", getSeverityColor(alert.severity).replace('text', 'text-current').replace('border', 'border-0'))}>
                    {getAlertIcon(alert.alertType)}
                  </div>
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <h3 className="font-bold text-white text-lg">{alert.description}</h3>
                      <span className={cn("px-2 py-0.5 text-[10px] font-bold uppercase rounded-full border", getSeverityColor(alert.severity))}>
                        {alert.severity}
                      </span>
                      {!isOpen && (
                        <span className="px-2 py-0.5 text-[10px] font-bold uppercase rounded-full bg-white/10 text-white/50 border border-white/10">
                          {alert.status}
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">Type: {alert.alertType.replace('_', ' ').toUpperCase()}</p>
                    <p className="text-xs text-muted-foreground mt-2">Detected: {format(new Date(alert.createdAt), "MMM d, yyyy 'at' h:mm a")}</p>
                  </div>
                </div>

                {isOpen && (
                  <div className="flex gap-3 w-full md:w-auto shrink-0">
                    <Button onClick={() => handleResolve(alert.id)} disabled={resolveMutation.isPending} className="bg-primary hover:bg-primary/90 text-white flex-1 md:flex-none rounded-xl">
                      Resolve Issue
                    </Button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </Layout>
  );
}
