import React from "react";
import { type Card } from "@workspace/api-client-react";
import { Wifi, CircleDollarSign } from "lucide-react";
import { cn } from "@/lib/utils";

interface VisualCardProps {
  card: Card;
  className?: string;
}

export function VisualCard({ card, className }: VisualCardProps) {
  const getGradient = () => {
    switch (card.cardType) {
      case "virtual": return "card-gradient-virtual";
      case "credit": return "card-gradient-credit";
      default: return "card-gradient-debit";
    }
  };

  const isBlocked = card.status === "blocked" || card.status === "expired";
  const isPending = card.status === "pending";

  return (
    <div 
      className={cn(
        "relative w-full aspect-[1.586/1] rounded-2xl p-6 flex flex-col justify-between overflow-hidden shadow-2xl transition-transform duration-300",
        getGradient(),
        isBlocked && "grayscale opacity-75",
        className
      )}
    >
      {/* Decorative background overlay */}
      <div className="absolute inset-0 bg-black/10 mix-blend-overlay pointer-events-none" />
      <div className="absolute -right-16 -top-16 w-64 h-64 rounded-full border border-white/10 pointer-events-none" />
      <div className="absolute -right-8 -top-8 w-48 h-48 rounded-full border border-white/10 pointer-events-none" />

      <div className="flex justify-between items-start relative z-10">
        <div className="flex flex-col">
          <span className="text-white/80 font-semibold uppercase tracking-widest text-xs">
            {card.cardType} Card
          </span>
          {isPending && (
            <span className="mt-1 px-2 py-0.5 bg-yellow-500/20 text-yellow-300 text-[10px] uppercase font-bold rounded-full w-fit">
              Activation Required
            </span>
          )}
          {isBlocked && (
            <span className="mt-1 px-2 py-0.5 bg-red-500/20 text-red-300 text-[10px] uppercase font-bold rounded-full w-fit">
              {card.status}
            </span>
          )}
        </div>
        {card.isContactless && (
          <Wifi className="w-6 h-6 text-white/80 rotate-90" />
        )}
      </div>

      <div className="relative z-10 flex flex-col gap-4">
        {/* EMV Chip placeholder */}
        <div className="w-12 h-9 rounded bg-gradient-to-br from-yellow-200 to-yellow-500 opacity-90" />
        
        <div className="font-mono text-2xl tracking-[0.2em] text-white font-medium drop-shadow-md">
          **** **** **** {card.cardNumber.slice(-4) || "XXXX"}
        </div>

        <div className="flex justify-between items-end">
          <div className="flex flex-col">
            <span className="text-white/50 text-[10px] uppercase tracking-wider">Cardholder Name</span>
            <span className="text-white font-medium tracking-wide uppercase truncate max-w-[180px]">
              {card.cardholderName}
            </span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-white/50 text-[10px] uppercase tracking-wider">Expires</span>
            <span className="text-white font-medium tracking-widest">
              {String(card.expiryMonth).padStart(2, '0')}/{String(card.expiryYear).slice(-2)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
