import { useState, useRef, useEffect } from "react";
import { useAuth } from "./use-auth";
import { 
  useGetChatSessions, 
  useCreateChatSession, 
  useGetChatMessages,
  getGetChatSessionsQueryKey,
  getGetChatMessagesQueryKey,
  type ChatMessage
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

export function useChatSessions() {
  const { getAuthHeaders } = useAuth();
  const queryClient = useQueryClient();
  
  const sessions = useGetChatSessions({ request: { headers: getAuthHeaders() } });
  
  const createSession = useCreateChatSession({
    request: { headers: getAuthHeaders() },
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetChatSessionsQueryKey() });
      }
    }
  });

  return { sessions, createSession };
}

export function useChatMessages(sessionId: number) {
  const { getAuthHeaders } = useAuth();
  return useGetChatMessages(sessionId, { 
    request: { headers: getAuthHeaders() },
    query: { enabled: !!sessionId }
  });
}

// Custom hook for the SSE streaming chat endpoint
export function useChatStream(sessionId: number | null) {
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamedContent, setStreamedContent] = useState("");
  const { getAuthHeaders } = useAuth();
  const queryClient = useQueryClient();

  const sendMessage = async (content: string) => {
    if (!sessionId) return;
    
    setIsStreaming(true);
    setStreamedContent("");
    
    try {
      const res = await fetch(`/api/chatbot/sessions/${sessionId}/messages`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...getAuthHeaders()
        },
        body: JSON.stringify({ content })
      });

      if (!res.ok) throw new Error("Failed to send message");
      if (!res.body) throw new Error("No response body");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        
        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split("\n\n");
        
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.done) {
                // Done streaming
              } else if (data.content) {
                setStreamedContent(prev => prev + data.content);
              }
            } catch (e) {
              console.error("Failed to parse SSE chunk", e);
            }
          }
        }
      }
    } catch (err) {
      console.error("Chat streaming error:", err);
    } finally {
      setIsStreaming(false);
      // Invalidate messages list so it fetches the final persisted text
      if (sessionId) {
        queryClient.invalidateQueries({ queryKey: getGetChatMessagesQueryKey(sessionId) });
      }
    }
  };

  return { sendMessage, isStreaming, streamedContent };
}
