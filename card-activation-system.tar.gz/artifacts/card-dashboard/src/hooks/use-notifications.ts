import { useAuth } from "./use-auth";
import {
  useGetNotifications,
  useGetNotificationPreferences,
  useUpdateNotificationPreferences,
  getGetNotificationPreferencesQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

export function useNotificationsHistory() {
  const { getAuthHeaders } = useAuth();
  return useGetNotifications({ request: { headers: getAuthHeaders() } });
}

export function useNotificationPrefs() {
  const { getAuthHeaders } = useAuth();
  const queryClient = useQueryClient();
  
  const prefsQuery = useGetNotificationPreferences({ request: { headers: getAuthHeaders() } });
  
  const updatePrefs = useUpdateNotificationPreferences({
    request: { headers: getAuthHeaders() },
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetNotificationPreferencesQueryKey() });
      }
    }
  });

  return { prefsQuery, updatePrefs };
}
