import { useSendOtp, useVerifyOtp } from "@workspace/api-client-react";
import { useAuth } from "./use-auth";

export function useOtp() {
  const { getAuthHeaders } = useAuth();
  
  const sendOtp = useSendOtp({
    request: { headers: getAuthHeaders() }
  });

  const verifyOtp = useVerifyOtp({
    request: { headers: getAuthHeaders() }
  });

  return { sendOtp, verifyOtp };
}
