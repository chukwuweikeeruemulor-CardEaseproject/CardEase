import { useHandleUssdSession } from "@workspace/api-client-react";
import { useAuth } from "./use-auth";

export function useUssd() {
  const { getAuthHeaders } = useAuth();
  return useHandleUssdSession({
    request: { headers: getAuthHeaders() }
  });
}
