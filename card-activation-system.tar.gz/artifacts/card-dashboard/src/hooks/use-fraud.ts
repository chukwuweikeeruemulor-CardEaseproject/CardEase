import { useAuth } from "./use-auth";
import {
  useGetFraudAlerts,
  useResolveFraudAlert,
  getGetFraudAlertsQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

export function useFraudAlerts() {
  const { getAuthHeaders } = useAuth();
  return useGetFraudAlerts({ request: { headers: getAuthHeaders() } });
}

export function useResolveAlert() {
  const { getAuthHeaders } = useAuth();
  const queryClient = useQueryClient();
  return useResolveFraudAlert({
    request: { headers: getAuthHeaders() },
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetFraudAlertsQueryKey() });
      }
    }
  });
}
