import { useAuth } from "./use-auth";
import {
  useGetCards,
  useGetCard,
  useLinkCard,
  useActivateCard,
  useSetPin,
  useBlockCard,
  useUnblockCard,
  useUpdateCardLimits,
  getGetCardsQueryKey,
  getGetCardQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

export function useCards() {
  const { getAuthHeaders } = useAuth();
  return useGetCards({ request: { headers: getAuthHeaders() } });
}

export function useCard(id: number) {
  const { getAuthHeaders } = useAuth();
  return useGetCard(id, { request: { headers: getAuthHeaders() } });
}

export function useLinkNewCard() {
  const { getAuthHeaders } = useAuth();
  const queryClient = useQueryClient();
  return useLinkCard({
    request: { headers: getAuthHeaders() },
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetCardsQueryKey() });
      }
    }
  });
}

export function useActivateNewCard() {
  const { getAuthHeaders } = useAuth();
  const queryClient = useQueryClient();
  return useActivateCard({
    request: { headers: getAuthHeaders() },
    mutation: {
      onSuccess: (_, variables) => {
        queryClient.invalidateQueries({ queryKey: getGetCardsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetCardQueryKey(variables.id) });
      }
    }
  });
}

export function useSetCardPin() {
  const { getAuthHeaders } = useAuth();
  return useSetPin({ request: { headers: getAuthHeaders() } });
}

export function useToggleCardBlock() {
  const { getAuthHeaders } = useAuth();
  const queryClient = useQueryClient();
  
  const blockMutation = useBlockCard({
    request: { headers: getAuthHeaders() },
    mutation: {
      onSuccess: (_, vars) => {
        queryClient.invalidateQueries({ queryKey: getGetCardsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetCardQueryKey(vars.id) });
      }
    }
  });

  const unblockMutation = useUnblockCard({
    request: { headers: getAuthHeaders() },
    mutation: {
      onSuccess: (_, vars) => {
        queryClient.invalidateQueries({ queryKey: getGetCardsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetCardQueryKey(vars.id) });
      }
    }
  });

  return { blockMutation, unblockMutation };
}

export function useUpdateLimits() {
  const { getAuthHeaders } = useAuth();
  const queryClient = useQueryClient();
  return useUpdateCardLimits({
    request: { headers: getAuthHeaders() },
    mutation: {
      onSuccess: (_, vars) => {
        queryClient.invalidateQueries({ queryKey: getGetCardsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetCardQueryKey(vars.id) });
      }
    }
  });
}
