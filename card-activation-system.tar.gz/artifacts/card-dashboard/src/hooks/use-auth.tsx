import React, { createContext, useContext, useState, useEffect } from "react";
import { useLocation } from "wouter";
import { 
  useGetMe, 
  useLoginUser, 
  useRegisterUser, 
  type User, 
  type LoginUserBody, 
  type RegisterUserBody 
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "@/hooks/use-toast";

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  token: string | null;
  login: (data: LoginUserBody) => Promise<void>;
  register: (data: RegisterUserBody) => Promise<void>;
  logout: () => void;
  getAuthHeaders: () => { Authorization: string } | {};
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = useState<string | null>(localStorage.getItem("atm_auth_token"));
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  const authHeaders = token ? { Authorization: `Bearer ${token}` } : {};

  const { data: user, isLoading: isUserLoading, error } = useGetMe({
    request: { headers: authHeaders },
    query: {
      enabled: !!token,
      retry: false,
    }
  });

  useEffect(() => {
    if (error) {
      logout();
    }
  }, [error]);

  const loginMutation = useLoginUser();
  const registerMutation = useRegisterUser();

  const login = async (data: LoginUserBody) => {
    try {
      const res = await loginMutation.mutateAsync({ data });
      localStorage.setItem("atm_auth_token", res.token);
      setToken(res.token);
      queryClient.setQueryData([`/api/auth/me`], res.user);
      setLocation("/");
      toast({ title: "Welcome back", description: "Successfully logged in." });
    } catch (err: any) {
      toast({ title: "Login failed", description: err.data?.error || "Invalid credentials", variant: "destructive" });
      throw err;
    }
  };

  const register = async (data: RegisterUserBody) => {
    try {
      const res = await registerMutation.mutateAsync({ data });
      localStorage.setItem("atm_auth_token", res.token);
      setToken(res.token);
      queryClient.setQueryData([`/api/auth/me`], res.user);
      setLocation("/auth/verify"); // Redirect to OTP verification after registration
      toast({ title: "Account created", description: "Please verify your account." });
    } catch (err: any) {
      toast({ title: "Registration failed", description: err.data?.error || "Could not create account", variant: "destructive" });
      throw err;
    }
  };

  const logout = () => {
    localStorage.removeItem("atm_auth_token");
    setToken(null);
    queryClient.clear();
    setLocation("/auth/login");
  };

  const getAuthHeaders = () => authHeaders;

  return (
    <AuthContext.Provider value={{
      user: user || null,
      isLoading: isUserLoading,
      token,
      login,
      register,
      logout,
      getAuthHeaders
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
