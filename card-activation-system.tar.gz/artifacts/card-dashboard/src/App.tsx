import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/hooks/use-auth";
import NotFound from "@/pages/not-found";

// Pages
import Login from "@/pages/auth/login";
import Register from "@/pages/auth/register";
import Dashboard from "@/pages/dashboard";
import CardsList from "@/pages/cards/list";
import CardDetail from "@/pages/cards/detail";
import ActivateCard from "@/pages/cards/activate";
import Chatbot from "@/pages/chatbot";
import FraudAlerts from "@/pages/fraud";
import Notifications from "@/pages/notifications";
import UssdSimulator from "@/pages/ussd";

const queryClient = new QueryClient();

// Auth Guard Component
function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isLoading, token } = useAuth();

  if (isLoading) {
    return <div className="min-h-screen bg-background flex items-center justify-center text-white">Loading...</div>;
  }

  if (!token) {
    window.location.href = import.meta.env.BASE_URL + "auth/login";
    return null;
  }

  return <Component />;
}

function Router() {
  return (
    <Switch>
      <Route path="/auth/login" component={Login} />
      <Route path="/auth/register" component={Register} />
      <Route path="/auth/verify" component={Register} />
      
      {/* Protected Routes */}
      <Route path="/" component={() => <ProtectedRoute component={Dashboard} />} />
      <Route path="/cards" component={() => <ProtectedRoute component={CardsList} />} />
      <Route path="/cards/:id" component={() => <ProtectedRoute component={CardDetail} />} />
      <Route path="/activate/:id" component={() => <ProtectedRoute component={ActivateCard} />} />
      <Route path="/chatbot" component={() => <ProtectedRoute component={Chatbot} />} />
      <Route path="/fraud" component={() => <ProtectedRoute component={FraudAlerts} />} />
      <Route path="/notifications" component={() => <ProtectedRoute component={Notifications} />} />
      <Route path="/ussd" component={() => <ProtectedRoute component={UssdSimulator} />} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
        <AuthProvider>
          <TooltipProvider>
            <Router />
            <Toaster />
          </TooltipProvider>
        </AuthProvider>
      </WouterRouter>
    </QueryClientProvider>
  );
}

export default App;
