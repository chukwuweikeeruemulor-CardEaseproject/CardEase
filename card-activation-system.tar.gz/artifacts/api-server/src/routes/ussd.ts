import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { usersTable, cardsTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { z } from "zod";

const router: IRouter = Router();

const ussdSchema = z.object({
  sessionId: z.string(),
  serviceCode: z.string(),
  phoneNumber: z.string(),
  text: z.string(),
});

router.post("/session", async (req, res) => {
  const parsed = ussdSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid USSD request" });
    return;
  }

  const { phoneNumber, text } = parsed.data;
  const input = text.split("*");
  const level = input.filter(Boolean).length;

  const users = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.phone, phoneNumber))
    .limit(1);

  const isRegistered = users.length > 0;

  if (text === "" || text === "*") {
    res.json({
      responseType: "CON",
      message: `Welcome to CardActivate\n1. Activate Card\n2. Block Card\n3. Check Card Status\n4. PIN Management\n5. Help`,
    });
    return;
  }

  if (text === "1") {
    if (!isRegistered) {
      res.json({
        responseType: "END",
        message: "Please register via our mobile app or website first.",
      });
      return;
    }
    res.json({
      responseType: "CON",
      message: `Card Activation\nEnter last 4 digits of your card:`,
    });
    return;
  }

  if (text.startsWith("1*") && level === 2) {
    res.json({
      responseType: "CON",
      message: `An OTP has been sent to ${phoneNumber}.\nEnter OTP to activate:`,
    });
    return;
  }

  if (text.startsWith("1*") && level === 3) {
    res.json({
      responseType: "END",
      message: `Card activation successful!\nYour card is now active.\nYou can set your PIN via our app.\nThank you for using CardActivate.`,
    });
    return;
  }

  if (text === "2") {
    if (!isRegistered) {
      res.json({
        responseType: "END",
        message: "Please register via our mobile app or website first.",
      });
      return;
    }
    res.json({
      responseType: "CON",
      message: `Block Card\nEnter last 4 digits of card to block:`,
    });
    return;
  }

  if (text.startsWith("2*") && level === 2) {
    res.json({
      responseType: "CON",
      message: `Confirm blocking?\n1. Yes, block card\n2. Cancel`,
    });
    return;
  }

  if (text.startsWith("2*") && level === 3 && input[2] === "1") {
    res.json({
      responseType: "END",
      message: `Card blocked successfully.\nContact support or use the app to unblock.\nFor emergencies call: 0800-CARD-HELP`,
    });
    return;
  }

  if (text === "3") {
    if (!isRegistered) {
      res.json({
        responseType: "END",
        message: "Please register via our mobile app or website first.",
      });
      return;
    }
    const cards = await db.select().from(cardsTable).where(eq(cardsTable.userId, users[0].id));
    if (cards.length === 0) {
      res.json({
        responseType: "END",
        message: "No cards linked to this number.\nLink a card via our app.",
      });
      return;
    }
    const cardList = cards
      .map((c, i) => `${i + 1}. ****${c.cardNumber.slice(-4)} - ${c.status.toUpperCase()}`)
      .join("\n");
    res.json({
      responseType: "END",
      message: `Your Cards:\n${cardList}\n\nUse our app for full card management.`,
    });
    return;
  }

  if (text === "4") {
    res.json({
      responseType: "CON",
      message: `PIN Management\n1. Set New PIN\n2. Reset PIN`,
    });
    return;
  }

  if (text === "4*1" || text === "4*2") {
    res.json({
      responseType: "END",
      message: `For security, PIN management is only available via our mobile app or web dashboard.\nVisit: cardactivate.app\nOr call: 0800-CARD-HELP`,
    });
    return;
  }

  if (text === "5") {
    res.json({
      responseType: "END",
      message: `CardActivate Help\n- App: cardactivate.app\n- Email: support@cardactivate.com\n- Phone: 0800-CARD-HELP\n- Hours: 24/7`,
    });
    return;
  }

  res.json({
    responseType: "END",
    message: `Invalid option. Please try again.\nDial *737# to restart.`,
  });
});

export default router;
