import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { notificationsTable, notificationPreferencesTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { requireAuth, type AuthRequest } from "../lib/auth.js";
import { z } from "zod";

const router: IRouter = Router();

router.get("/", requireAuth, async (req: AuthRequest, res) => {
  const notifications = await db
    .select()
    .from(notificationsTable)
    .where(eq(notificationsTable.userId, req.userId!))
    .orderBy(notificationsTable.createdAt);
  res.json(
    notifications.map((n) => ({
      id: n.id,
      userId: n.userId,
      title: n.title,
      body: n.body,
      channel: n.channel,
      isRead: n.isRead,
      createdAt: n.createdAt.toISOString(),
    }))
  );
});

router.get("/preferences", requireAuth, async (req: AuthRequest, res) => {
  const [prefs] = await db
    .select()
    .from(notificationPreferencesTable)
    .where(eq(notificationPreferencesTable.userId, req.userId!))
    .limit(1);

  if (!prefs) {
    const [created] = await db
      .insert(notificationPreferencesTable)
      .values({ userId: req.userId! })
      .returning();
    res.json({
      smsEnabled: created.smsEnabled,
      emailEnabled: created.emailEnabled,
      pushEnabled: created.pushEnabled,
      transactionAlerts: created.transactionAlerts,
      securityAlerts: created.securityAlerts,
      marketingAlerts: created.marketingAlerts,
    });
    return;
  }

  res.json({
    smsEnabled: prefs.smsEnabled,
    emailEnabled: prefs.emailEnabled,
    pushEnabled: prefs.pushEnabled,
    transactionAlerts: prefs.transactionAlerts,
    securityAlerts: prefs.securityAlerts,
    marketingAlerts: prefs.marketingAlerts,
  });
});

const prefsSchema = z.object({
  smsEnabled: z.boolean().optional(),
  emailEnabled: z.boolean().optional(),
  pushEnabled: z.boolean().optional(),
  transactionAlerts: z.boolean().optional(),
  securityAlerts: z.boolean().optional(),
  marketingAlerts: z.boolean().optional(),
});

router.patch("/preferences", requireAuth, async (req: AuthRequest, res) => {
  const parsed = prefsSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid preferences" });
    return;
  }

  const existing = await db
    .select()
    .from(notificationPreferencesTable)
    .where(eq(notificationPreferencesTable.userId, req.userId!))
    .limit(1);

  let result;
  if (existing.length === 0) {
    [result] = await db
      .insert(notificationPreferencesTable)
      .values({ userId: req.userId!, ...parsed.data })
      .returning();
  } else {
    [result] = await db
      .update(notificationPreferencesTable)
      .set({ ...parsed.data, updatedAt: new Date() })
      .where(eq(notificationPreferencesTable.userId, req.userId!))
      .returning();
  }

  res.json({
    smsEnabled: result.smsEnabled,
    emailEnabled: result.emailEnabled,
    pushEnabled: result.pushEnabled,
    transactionAlerts: result.transactionAlerts,
    securityAlerts: result.securityAlerts,
    marketingAlerts: result.marketingAlerts,
  });
});

export default router;
