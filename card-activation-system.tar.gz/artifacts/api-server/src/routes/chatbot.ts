import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { chatSessionsTable, chatMessagesTable } from "@workspace/db/schema";
import { eq } from "drizzle-orm";
import { requireAuth, type AuthRequest } from "../lib/auth.js";
import { openai } from "@workspace/integrations-openai-ai-server";
import { z } from "zod";

const router: IRouter = Router();

const SYSTEM_PROMPT = `You are CardAssist, an AI support agent for a secure Digital ATM Card Activation System.
You help users with:
- Card activation (no ATM required)
- PIN creation and reset
- Card blocking/unblocking
- Spending limit adjustments
- Understanding transaction alerts and fraud notifications
- General card management questions

Always be professional, concise, and security-conscious. Never ask users to share their full card number, PIN, or OTP codes. 
If you detect a potential security threat based on user description, flag it and advise the user to block their card immediately.

For card activation: Guide users to go to Cards > Select Card > Activate Card, then verify via OTP.
For PIN reset: Go to Cards > Select Card > Set PIN, then verify via OTP.
For blocking: Go to Cards > Select Card > Block Card.`;

router.get("/sessions", requireAuth, async (req: AuthRequest, res) => {
  const sessions = await db
    .select()
    .from(chatSessionsTable)
    .where(eq(chatSessionsTable.userId, req.userId!))
    .orderBy(chatSessionsTable.createdAt);
  res.json(
    sessions.map((s) => ({
      id: s.id,
      userId: s.userId,
      title: s.title,
      createdAt: s.createdAt.toISOString(),
    }))
  );
});

router.post("/sessions", requireAuth, async (req: AuthRequest, res) => {
  const [session] = await db
    .insert(chatSessionsTable)
    .values({ userId: req.userId!, title: "New Conversation" })
    .returning();
  res.status(201).json({
    id: session.id,
    userId: session.userId,
    title: session.title,
    createdAt: session.createdAt.toISOString(),
  });
});

router.get("/sessions/:id/messages", requireAuth, async (req: AuthRequest, res) => {
  const sessionId = parseInt(req.params.id);
  const [session] = await db
    .select()
    .from(chatSessionsTable)
    .where(eq(chatSessionsTable.id, sessionId))
    .limit(1);

  if (!session || session.userId !== req.userId!) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  const messages = await db
    .select()
    .from(chatMessagesTable)
    .where(eq(chatMessagesTable.sessionId, sessionId))
    .orderBy(chatMessagesTable.createdAt);

  res.json(
    messages.map((m) => ({
      id: m.id,
      sessionId: m.sessionId,
      role: m.role,
      content: m.content,
      createdAt: m.createdAt.toISOString(),
    }))
  );
});

const sendMessageSchema = z.object({ content: z.string().min(1) });

router.post("/sessions/:id/messages", requireAuth, async (req: AuthRequest, res) => {
  const sessionId = parseInt(req.params.id);
  const parsed = sendMessageSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Message content required" });
    return;
  }

  const [session] = await db
    .select()
    .from(chatSessionsTable)
    .where(eq(chatSessionsTable.id, sessionId))
    .limit(1);

  if (!session || session.userId !== req.userId!) {
    res.status(404).json({ error: "Session not found" });
    return;
  }

  const userContent = parsed.data.content;

  await db.insert(chatMessagesTable).values({
    sessionId,
    role: "user",
    content: userContent,
  });

  if (session.title === "New Conversation") {
    const shortTitle = userContent.slice(0, 50);
    await db.update(chatSessionsTable).set({ title: shortTitle }).where(eq(chatSessionsTable.id, sessionId));
  }

  const history = await db
    .select()
    .from(chatMessagesTable)
    .where(eq(chatMessagesTable.sessionId, sessionId))
    .orderBy(chatMessagesTable.createdAt);

  const chatMessages = [
    { role: "system" as const, content: SYSTEM_PROMPT },
    ...history.map((m) => ({
      role: m.role as "user" | "assistant",
      content: m.content,
    })),
  ];

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  let fullResponse = "";

  try {
    const stream = await openai.chat.completions.create({
      model: "gpt-5.2",
      max_completion_tokens: 8192,
      messages: chatMessages,
      stream: true,
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        fullResponse += content;
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }

    await db.insert(chatMessagesTable).values({
      sessionId,
      role: "assistant",
      content: fullResponse,
    });

    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
  } catch (err) {
    req.log.error({ err }, "Chatbot error");
    res.write(`data: ${JSON.stringify({ error: "AI service error" })}\n\n`);
    res.end();
  }
});

export default router;
