import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import authRouter from "./auth.js";
import otpRouter from "./otp.js";
import cardsRouter from "./cards.js";
import fraudRouter from "./fraud.js";
import notificationsRouter from "./notifications.js";
import chatbotRouter from "./chatbot.js";
import ussdRouter from "./ussd.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/otp", otpRouter);
router.use("/cards", cardsRouter);
router.use("/fraud", fraudRouter);
router.use("/notifications", notificationsRouter);
router.use("/chatbot", chatbotRouter);
router.use("/ussd", ussdRouter);

export default router;
