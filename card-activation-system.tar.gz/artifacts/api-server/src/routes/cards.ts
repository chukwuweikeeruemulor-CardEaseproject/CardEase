import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { cardsTable, fraudAlertsTable, notificationsTable } from "@workspace/db/schema";
import { eq, and } from "drizzle-orm";
import { requireAuth, hashPin, maskCardNumber, encryptCardNumber, type AuthRequest } from "../lib/auth.js";
import { z } from "zod";

const router: IRouter = Router();

function formatCard(card: typeof cardsTable.$inferSelect) {
  return {
    id: card.id,
    userId: card.userId,
    cardNumber: maskCardNumber(card.cardNumber),
    cardholderName: card.cardholderName,
    cardType: card.cardType,
    status: card.status,
    expiryMonth: card.expiryMonth,
    expiryYear: card.expiryYear,
    dailyLimit: Number(card.dailyLimit),
    monthlyLimit: Number(card.monthlyLimit),
    isContactless: card.isContactless,
    isOnlineEnabled: card.isOnlineEnabled,
    isInternationalEnabled: card.isInternationalEnabled,
    activatedAt: card.activatedAt?.toISOString() ?? null,
    createdAt: card.createdAt.toISOString(),
  };
}

router.get("/", requireAuth, async (req: AuthRequest, res) => {
  const cards = await db.select().from(cardsTable).where(eq(cardsTable.userId, req.userId!));
  res.json(cards.map(formatCard));
});

router.get("/:id", requireAuth, async (req: AuthRequest, res) => {
  const id = parseInt(req.params.id);
  const [card] = await db.select().from(cardsTable).where(
    and(eq(cardsTable.id, id), eq(cardsTable.userId, req.userId!))
  ).limit(1);
  if (!card) {
    res.status(404).json({ error: "Card not found" });
    return;
  }
  res.json(formatCard(card));
});

const linkCardSchema = z.object({
  cardNumber: z.string().min(16).max(19),
  cardholderName: z.string().min(1),
  cardType: z.enum(["debit", "virtual", "credit"]),
  expiryMonth: z.number().int().min(1).max(12),
  expiryYear: z.number().int().min(2024),
});

router.post("/", requireAuth, async (req: AuthRequest, res) => {
  const parsed = linkCardSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid card data" });
    return;
  }
  const { cardNumber, cardholderName, cardType, expiryMonth, expiryYear } = parsed.data;
  const encryptedNumber = encryptCardNumber(cardNumber.replace(/\s/g, ""));

  const [card] = await db.insert(cardsTable).values({
    userId: req.userId!,
    cardNumber: encryptedNumber,
    cardholderName,
    cardType,
    expiryMonth,
    expiryYear,
    dailyLimit: "100000",
    monthlyLimit: "500000",
  }).returning();

  await db.insert(notificationsTable).values({
    userId: req.userId!,
    title: "New Card Linked",
    body: `Your ${cardType} card ending in ${cardNumber.slice(-4)} has been linked successfully.`,
    channel: "push",
  });

  res.status(201).json(formatCard(card));
});

const activateSchema = z.object({
  otpToken: z.string().min(1),
  deviceId: z.string().optional(),
});

router.post("/:id/activate", requireAuth, async (req: AuthRequest, res) => {
  const id = parseInt(req.params.id);
  const parsed = activateSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "OTP token required" });
    return;
  }

  const [card] = await db.select().from(cardsTable).where(
    and(eq(cardsTable.id, id), eq(cardsTable.userId, req.userId!))
  ).limit(1);

  if (!card) {
    res.status(404).json({ error: "Card not found" });
    return;
  }
  if (card.status === "active") {
    res.status(400).json({ error: "Card is already active" });
    return;
  }
  if (card.status === "blocked") {
    res.status(400).json({ error: "Card is blocked and cannot be activated" });
    return;
  }

  const [updated] = await db.update(cardsTable)
    .set({ status: "active", activatedAt: new Date() })
    .where(eq(cardsTable.id, id))
    .returning();

  await db.insert(notificationsTable).values({
    userId: req.userId!,
    title: "Card Activated",
    body: `Your card ending in ${card.cardNumber.slice(-4)} has been activated. You can now use it for transactions.`,
    channel: "push",
  });

  res.json(formatCard(updated));
});

const setPinSchema = z.object({
  pin: z.string().min(4).max(6).regex(/^\d+$/),
  otpToken: z.string().min(1),
});

router.post("/:id/pin", requireAuth, async (req: AuthRequest, res) => {
  const id = parseInt(req.params.id);
  const parsed = setPinSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Valid PIN (4-6 digits) and OTP token required" });
    return;
  }

  const [card] = await db.select().from(cardsTable).where(
    and(eq(cardsTable.id, id), eq(cardsTable.userId, req.userId!))
  ).limit(1);

  if (!card) {
    res.status(404).json({ error: "Card not found" });
    return;
  }

  const pinHash = await hashPin(parsed.data.pin);
  await db.update(cardsTable).set({ pinHash }).where(eq(cardsTable.id, id));

  await db.insert(notificationsTable).values({
    userId: req.userId!,
    title: "PIN Updated",
    body: `Your card PIN has been set successfully.`,
    channel: "push",
  });

  res.json({ message: "PIN set successfully" });
});

const blockSchema = z.object({ reason: z.string().min(1) });

router.post("/:id/block", requireAuth, async (req: AuthRequest, res) => {
  const id = parseInt(req.params.id);
  const parsed = blockSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Reason is required" });
    return;
  }

  const [card] = await db.select().from(cardsTable).where(
    and(eq(cardsTable.id, id), eq(cardsTable.userId, req.userId!))
  ).limit(1);

  if (!card) {
    res.status(404).json({ error: "Card not found" });
    return;
  }

  const [updated] = await db.update(cardsTable)
    .set({ status: "blocked", blockReason: parsed.data.reason })
    .where(eq(cardsTable.id, id))
    .returning();

  await db.insert(notificationsTable).values({
    userId: req.userId!,
    title: "Card Blocked",
    body: `Your card ending in ${card.cardNumber.slice(-4)} has been blocked. Reason: ${parsed.data.reason}`,
    channel: "push",
  });

  await db.insert(fraudAlertsTable).values({
    userId: req.userId!,
    cardId: id,
    alertType: "suspicious_pattern",
    severity: "medium",
    description: `Card manually blocked by user. Reason: ${parsed.data.reason}`,
  });

  res.json(formatCard(updated));
});

router.post("/:id/unblock", requireAuth, async (req: AuthRequest, res) => {
  const id = parseInt(req.params.id);
  const [card] = await db.select().from(cardsTable).where(
    and(eq(cardsTable.id, id), eq(cardsTable.userId, req.userId!))
  ).limit(1);

  if (!card) {
    res.status(404).json({ error: "Card not found" });
    return;
  }
  if (card.status !== "blocked") {
    res.status(400).json({ error: "Card is not blocked" });
    return;
  }

  const [updated] = await db.update(cardsTable)
    .set({ status: "active", blockReason: null })
    .where(eq(cardsTable.id, id))
    .returning();

  await db.insert(notificationsTable).values({
    userId: req.userId!,
    title: "Card Unblocked",
    body: `Your card ending in ${card.cardNumber.slice(-4)} has been unblocked and is now active.`,
    channel: "push",
  });

  res.json(formatCard(updated));
});

const limitsSchema = z.object({
  dailyLimit: z.number().positive().optional().nullable(),
  monthlyLimit: z.number().positive().optional().nullable(),
  isContactless: z.boolean().optional().nullable(),
  isOnlineEnabled: z.boolean().optional().nullable(),
  isInternationalEnabled: z.boolean().optional().nullable(),
});

router.patch("/:id/limits", requireAuth, async (req: AuthRequest, res) => {
  const id = parseInt(req.params.id);
  const parsed = limitsSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid limits data" });
    return;
  }

  const [card] = await db.select().from(cardsTable).where(
    and(eq(cardsTable.id, id), eq(cardsTable.userId, req.userId!))
  ).limit(1);

  if (!card) {
    res.status(404).json({ error: "Card not found" });
    return;
  }

  const updates: Partial<typeof cardsTable.$inferInsert> = {};
  if (parsed.data.dailyLimit != null) updates.dailyLimit = String(parsed.data.dailyLimit);
  if (parsed.data.monthlyLimit != null) updates.monthlyLimit = String(parsed.data.monthlyLimit);
  if (parsed.data.isContactless != null) updates.isContactless = parsed.data.isContactless;
  if (parsed.data.isOnlineEnabled != null) updates.isOnlineEnabled = parsed.data.isOnlineEnabled;
  if (parsed.data.isInternationalEnabled != null) updates.isInternationalEnabled = parsed.data.isInternationalEnabled;

  const [updated] = await db.update(cardsTable).set(updates).where(eq(cardsTable.id, id)).returning();
  res.json(formatCard(updated));
});

export default router;
