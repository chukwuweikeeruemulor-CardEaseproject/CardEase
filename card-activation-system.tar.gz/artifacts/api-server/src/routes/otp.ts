import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { otpsTable } from "@workspace/db/schema";
import { eq, and } from "drizzle-orm";
import { generateOtp, hashOtp, compareOtp } from "../lib/auth.js";
import { z } from "zod";

const router: IRouter = Router();

const sendSchema = z.object({
  destination: z.string().min(1),
  channel: z.enum(["sms", "email"]),
  purpose: z.enum(["registration", "card_activation", "pin_reset", "login"]),
});

const verifySchema = z.object({
  destination: z.string().min(1),
  otp: z.string().length(6),
  purpose: z.enum(["registration", "card_activation", "pin_reset", "login"]),
});

router.post("/send", async (req, res) => {
  const parsed = sendSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }
  const { destination, channel, purpose } = parsed.data;
  const otp = generateOtp();
  const otpHash = await hashOtp(otp);
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

  await db.insert(otpsTable).values({ destination, otpHash, purpose, expiresAt });

  req.log.info({ channel, purpose, destination }, `OTP generated (demo: ${otp})`);

  res.json({
    message: `OTP sent via ${channel} to ${destination}. Demo OTP: ${otp}`,
  });
});

router.post("/verify", async (req, res) => {
  const parsed = verifySchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }
  const { destination, otp, purpose } = parsed.data;

  const otps = await db
    .select()
    .from(otpsTable)
    .where(
      and(
        eq(otpsTable.destination, destination),
        eq(otpsTable.purpose, purpose),
        eq(otpsTable.isUsed, false),
      )
    )
    .orderBy(otpsTable.createdAt);

  const now = new Date();
  let matched: typeof otps[0] | null = null;

  for (const record of otps) {
    if (record.expiresAt < now) continue;
    const valid = await compareOtp(otp, record.otpHash);
    if (valid) {
      matched = record;
      break;
    }
  }

  if (!matched) {
    res.status(400).json({ error: "Invalid or expired OTP" });
    return;
  }

  await db.update(otpsTable).set({ isUsed: true }).where(eq(otpsTable.id, matched.id));

  const token = Buffer.from(`${destination}:${purpose}:${Date.now()}`).toString("base64");

  res.json({ verified: true, token });
});

export default router;
