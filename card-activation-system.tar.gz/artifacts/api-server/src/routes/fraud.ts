import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { fraudAlertsTable } from "@workspace/db/schema";
import { eq, and } from "drizzle-orm";
import { requireAuth, type AuthRequest } from "../lib/auth.js";

const router: IRouter = Router();

function formatAlert(alert: typeof fraudAlertsTable.$inferSelect) {
  return {
    id: alert.id,
    userId: alert.userId,
    cardId: alert.cardId,
    alertType: alert.alertType,
    severity: alert.severity,
    description: alert.description,
    status: alert.status,
    metadata: alert.metadata,
    createdAt: alert.createdAt.toISOString(),
    resolvedAt: alert.resolvedAt?.toISOString() ?? null,
  };
}

router.get("/alerts", requireAuth, async (req: AuthRequest, res) => {
  const alerts = await db
    .select()
    .from(fraudAlertsTable)
    .where(eq(fraudAlertsTable.userId, req.userId!))
    .orderBy(fraudAlertsTable.createdAt);
  res.json(alerts.map(formatAlert));
});

router.post("/alerts/:id/resolve", requireAuth, async (req: AuthRequest, res) => {
  const id = parseInt(req.params.id);
  const [alert] = await db
    .select()
    .from(fraudAlertsTable)
    .where(and(eq(fraudAlertsTable.id, id), eq(fraudAlertsTable.userId, req.userId!)))
    .limit(1);

  if (!alert) {
    res.status(404).json({ error: "Alert not found" });
    return;
  }

  const [updated] = await db
    .update(fraudAlertsTable)
    .set({ status: "resolved", resolvedAt: new Date() })
    .where(eq(fraudAlertsTable.id, id))
    .returning();

  res.json(formatAlert(updated));
});

export default router;
