import { pgTable, serial, text, integer, boolean, timestamp, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const cardsTable = pgTable("cards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  cardNumber: text("card_number").notNull(),
  cardholderName: text("cardholder_name").notNull(),
  cardType: text("card_type").notNull().default("debit"),
  status: text("status").notNull().default("pending"),
  expiryMonth: integer("expiry_month").notNull(),
  expiryYear: integer("expiry_year").notNull(),
  pinHash: text("pin_hash"),
  dailyLimit: numeric("daily_limit").notNull().default("100000"),
  monthlyLimit: numeric("monthly_limit").notNull().default("500000"),
  isContactless: boolean("is_contactless").notNull().default(true),
  isOnlineEnabled: boolean("is_online_enabled").notNull().default(true),
  isInternationalEnabled: boolean("is_international_enabled").notNull().default(false),
  blockReason: text("block_reason"),
  activatedAt: timestamp("activated_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCardSchema = createInsertSchema(cardsTable).omit({
  id: true,
  createdAt: true,
  status: true,
  pinHash: true,
  blockReason: true,
  activatedAt: true,
});

export type InsertCard = z.infer<typeof insertCardSchema>;
export type Card = typeof cardsTable.$inferSelect;
