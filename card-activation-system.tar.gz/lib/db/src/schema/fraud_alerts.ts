import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";
import { cardsTable } from "./cards";

export const fraudAlertsTable = pgTable("fraud_alerts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  cardId: integer("card_id").references(() => cardsTable.id),
  alertType: text("alert_type").notNull(),
  severity: text("severity").notNull().default("medium"),
  description: text("description").notNull(),
  status: text("status").notNull().default("open"),
  metadata: text("metadata"),
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertFraudAlertSchema = createInsertSchema(fraudAlertsTable).omit({
  id: true,
  createdAt: true,
  resolvedAt: true,
  status: true,
});

export type InsertFraudAlert = z.infer<typeof insertFraudAlertSchema>;
export type FraudAlert = typeof fraudAlertsTable.$inferSelect;
